from car import Car

ncar1 = Car("Porsche 911","911","10","2019","White","$92,000")
ucar1 = Car("Honda","Civic","10","2015","White","$15,000")
print(ncar1.color)
print(ucar1.price)
