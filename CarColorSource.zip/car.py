class Car:
    def __init__(self,make,model,year,mileage,color,price):
        self.make = make
        self.model = model
        self.year = year
        self.mileage = mileage
        self.color = color
        self.price = price
class Used(Car):
    def __init__(self,make,model,year,mileage,color,price):
      super().init(self)
      
